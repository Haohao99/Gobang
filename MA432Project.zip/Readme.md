Online Gobang Game

Description:
Online Gobang Game is a multiple player Gobang game. It supports a one player VS one player game on a eleven by eleven board. It is implemented by python with the help of pygame, pickle module and python sockets module.

Required module:
Python 3.0 or higher
pygame

How to run the game: 
Before you start the game, you need to change the server address inside the server.py and client.py file to ensure that you create/connect to the correct server.
To start with the game, you may enter “python server.py PORTNUM” in the terminal to run the server. Then you can enter “python client.py PORTNUM” to run the client program. After the player name is entered, the game window will pop out. The game will be waiting until both client programs are started with the player name entered.
